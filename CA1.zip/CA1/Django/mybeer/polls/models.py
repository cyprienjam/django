from django.db import models
import datetime
from django.utils import timezone


class Question(models.Model):
    # ...
    def __init__(self, *args, **kwargs):
        super().__init__(args, kwargs)
        self.pub_date = None

    def was_published_recently(self):
        return self.pub_date >= timezone.now() - datetime.timedelta(days=1)


def was_published_recently(self):
    now = timezone.now()
    return now - datetime.timedelta(days=1) <= self.pub_date <= now

